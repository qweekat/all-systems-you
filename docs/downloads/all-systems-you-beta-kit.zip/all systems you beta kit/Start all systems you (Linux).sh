#!/bin/sh
# Starts all systems you. Leave the window open while you use it.
# Double-click and choose "Run as a Program", or in a terminal:  sh "Start all systems you (Linux).sh"
cd "$(dirname "$0")" || exit 1
if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1; then
  echo ""
  echo "  all systems you needs Python 3. On Ubuntu or Debian, open a terminal and run:"
  echo "     sudo apt install python3"
  echo "  Then start all systems you again."
  echo ""
  printf "  Press Enter to close. "; read -r _
  exit 1
fi
python3 host/daily_helper_host.py
printf "\n  all systems you has stopped. Press Enter to close. "; read -r _
