@echo off
rem Double-click to start all systems you. Leave the window open while you use it.
title all systems you beta
cd /d "%~dp0"
set PY=
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
if not errorlevel 1 set PY=py -3
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
if not defined PY if not errorlevel 1 set PY=python
if not defined PY goto nopython
%PY% host\daily_helper_host.py
echo.
echo   all systems you has stopped.
pause
goto :eof
:nopython
echo.
echo   all systems you needs Python, which is free.
echo   The Python download page is opening now. Download and run the installer.
echo   On the first screen, tick "Add python.exe to PATH", then click Install Now.
echo   Then double-click "Start all systems you (Windows)" again.
echo.
start "" "https://www.python.org/downloads/windows/"
pause
