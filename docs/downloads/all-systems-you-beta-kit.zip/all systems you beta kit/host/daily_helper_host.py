#!/usr/bin/env python3
"""all systems you (beta): runs the app from this computer so phones on the same Wi-Fi can use it.

Works on Mac, Windows and Linux with plain Python 3.8 or newer. Nothing to install.
- Serves the app in ../app to this computer and to paired phones.
- Keeps one copy of the app and pantry data on this computer, so the computer
  and every paired phone see the same week, pantry and shopping list.
- Shows desktop pop-up reminders while this window is open.
Data lives in a "AllSystemsYouBeta" folder in your home folder. Nothing is sent anywhere.
"""
import datetime
import ipaddress
import json
import os
import platform
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

PORT = int(os.environ.get("DAILY_HELPER_PORT", "8770"))
HOST_DIR = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.dirname(HOST_DIR)
APP = os.path.join(KIT, "app")
DATA = os.environ.get("DAILY_HELPER_DATA") or os.path.join(os.path.expanduser("~"), "AllSystemsYouBeta")
STATE = os.path.join(DATA, "state.json")
REV = os.path.join(DATA, "state-rev.json")
REMINDERS = os.path.join(DATA, "reminders.json")
FIRED = os.path.join(DATA, "fired.json")
CONFIG = os.path.join(DATA, "config.json")
BACKUPS = os.path.join(DATA, "backups")
KEEP_BACKUPS = 7
SYSTEM = platform.system()  # "Darwin" (Mac), "Windows" or "Linux"
# Browser storage the pantry page keeps, mirrored here so the computer and phones share one copy.
KV_KEYS = {"pantryplanner.v1"}
HELPER_KEY = "dailyhelper.v1"
TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css",
         ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json",
         ".webmanifest": "application/manifest+json", ".txt": "text/plain; charset=utf-8"}
# Phones may fetch these before they're paired (home-screen icons).
OPEN_PATHS = re.compile(r"^/(manifest\.webmanifest|icons/[\w.-]+|qr\.js)$")
lock = threading.Lock()


def app_version():
    try:
        with open(os.path.join(APP, "sw.js"), encoding="utf-8") as f:
            m = re.search(r'(?:all-systems-you|daily-helper)-([\w.-]+)"', f.read())
            return m.group(1) if m else "?"
    except OSError:
        return "?"


VERSION = app_version()

# Every page: send the pairing key with each request, keep it in the address so "Add to Home Screen"
# keeps it too, and show the beta line with the feedback link.
HEAD_TAGS = """
<script>
(function(){
  var key = null;
  try{ key = new URLSearchParams(location.search).get("k"); if(key) localStorage.setItem("dh-k", key); else key = localStorage.getItem("dh-k"); }catch(e){}
  window.DH_KEY = key;
  if(!key) return;
  try{ var u = new URL(location.href); if(u.searchParams.get("k") !== key){ u.searchParams.set("k", key); history.replaceState(history.state, "", u.pathname + u.search + u.hash); } }catch(e){}
  var f = window.fetch;
  window.fetch = function(u, o){
    o = o || {};
    if(typeof u === "string" && u.charAt(0) === "/"){ o.headers = Object.assign({}, o.headers || {}, {"X-DH-Key": key}); }
    return f.call(this, u, o);
  };
  var op = XMLHttpRequest.prototype.open, sd = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, u){ this._dhLocal = typeof u === "string" && u.charAt(0) === "/"; return op.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(){ if(this._dhLocal) this.setRequestHeader("X-DH-Key", key); return sd.apply(this, arguments); };
})();
document.addEventListener("DOMContentLoaded", function(){
  var b = document.createElement("div"); b.className = "dh-beta";
  b.innerHTML = 'Beta test version __VERSION__ &middot; <a href="/feedback.html">Send feedback</a>';
  document.body.insertBefore(b, document.body.firstChild);
});
</script>
<style>
.dh-beta{font:14px/1.3 system-ui,-apple-system,sans-serif;text-align:center;padding:calc(6px + env(safe-area-inset-top,0px)) 12px 6px;background:#fff4d6;color:#5a4500;border-bottom:1px solid #ecd9a0}
.dh-beta a{color:#2f5f9e;font-weight:600}
@media (prefers-color-scheme:dark){.dh-beta{background:#3a3012;color:#f1e2b0;border-color:#5a4a1c}.dh-beta a{color:#9cc3ff}}
@media print{.dh-beta{display:none !important}}
</style>
""".replace("__VERSION__", VERSION)

# Other pages get the latest app data (rules, week) from the computer before their own code runs.
HELPER_STATE = """
<script>
(function(){
  try{ var x = new XMLHttpRequest(); x.open("GET", "/api/state", false); x.send();
    if(x.status === 200){ var j = JSON.parse(x.responseText); if(j && j.state) Storage.prototype.setItem.call(localStorage, "%s", JSON.stringify(j.state)); } }catch(e){}
})();
</script>
""" % HELPER_KEY

# Keeps the pantry page's saved data on the computer, so every phone sees the same pantry and shopping list.
PANTRY_SYNC = """
<script>
(function(){
  var KEY = "pantryplanner.v1";
  function get(u){ try{ var x = new XMLHttpRequest(); x.open("GET", u, false); x.send(); if(x.status === 200) return JSON.parse(x.responseText); }catch(e){} return null; }
  var last = null, timer = null, orig = Storage.prototype.setItem;
  function push(v){ last = v; try{ fetch("/api/kv/" + KEY, {method:"PUT", keepalive:true, headers:{"Content-Type":"application/json"}, body:JSON.stringify({value:v})}); }catch(e){} }
  try{
    var kv = get("/api/kv/" + KEY);
    if(kv && typeof kv.value === "string"){ last = kv.value; orig.call(localStorage, KEY, kv.value); }
    else if(kv){ var cur = localStorage.getItem(KEY); if(cur) push(cur); }
  }catch(e){}
  Storage.prototype.setItem = function(k, v){
    orig.call(this, k, v);
    if(this === localStorage && k === KEY){ clearTimeout(timer); timer = setTimeout(function(){ push(String(v)); }, 300); }
  };
  document.addEventListener("visibilitychange", function(){
    if(document.visibilityState !== "visible") return;
    var n = get("/api/kv/" + KEY);
    if(n && typeof n.value === "string" && n.value !== last && n.value !== localStorage.getItem(KEY)) location.reload();
  });
})();
</script>
<style>#btn-label{display:none !important}</style>
"""

NOT_PAIRED = """<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>all systems you</title><body style="font:18px/1.5 system-ui,sans-serif;max-width:30em;margin:2em auto;padding:0 16px">
<h1>all systems you</h1><p>%s</p></body>"""


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, path)


def daily_backup():
    """Once a day, before the first change, keep a copy of everything. Call with lock held."""
    day = datetime.date.today().isoformat()
    path = os.path.join(BACKUPS, day + ".json")
    if os.path.exists(path) or not os.path.exists(STATE):
        return
    os.makedirs(BACKUPS, exist_ok=True)
    kv = {k: read_json(os.path.join(DATA, "kv-" + k + ".json"), {"value": None}).get("value") for k in KV_KEYS}
    write_json(path, {"day": day, "state": read_json(STATE, None), "kv": kv})
    old = sorted(f for f in os.listdir(BACKUPS) if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.json", f))
    for f in old[:-KEEP_BACKUPS]:
        os.remove(os.path.join(BACKUPS, f))


def config():
    with lock:
        c = read_json(CONFIG, {})
        if not c.get("token"):
            c = {"phones": bool(c.get("phones")), "token": secrets.token_urlsafe(16)}
            write_json(CONFIG, c)
    return c


def lan_addresses():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))  # picks the Wi-Fi address; nothing is sent
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    if SYSTEM == "Linux":
        try:
            out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5).stdout.split()
            ips.update(i for i in out if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", i))
        except (OSError, subprocess.SubprocessError):
            pass
    keep = []
    for i in ips:
        a = ipaddress.ip_address(i)
        if a.is_private and not a.is_loopback and not a.is_link_local and not i.startswith("172.17."):
            keep.append(i)
    return sorted(keep)


def local_name():
    """The computer's name on the home network (name.local). iPhones find it even if the Wi-Fi address changes.
    Windows doesn't answer to it reliably, so there the Wi-Fi address is used instead."""
    if SYSTEM == "Windows":
        ips = lan_addresses()
        return ips[0] if ips else "localhost"
    name = ""
    if SYSTEM == "Darwin":
        try:
            name = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=5).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            pass
    name = name or socket.gethostname()
    return name if name.endswith(".local") else name + ".local"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, obj, code=200):
        self.send(code, json.dumps(obj).encode(), "application/json")

    # ---------- who is asking ----------
    def is_computer(self):
        try:
            a = ipaddress.ip_address(self.client_address[0])
            return a.is_loopback or (a.version == 6 and a.ipv4_mapped is not None and a.ipv4_mapped.is_loopback)
        except ValueError:
            return False

    def query_key(self):
        return (parse_qs(urlsplit(self.path).query).get("k") or [""])[0]

    def allowed(self):
        if self.is_computer():
            return True
        c = config()
        if not c.get("phones"):
            return False
        cookie = SimpleCookie(self.headers.get("Cookie") or "")
        given = [self.headers.get("X-DH-Key") or "", self.query_key(),
                 cookie["dh_k"].value if "dh_k" in cookie else ""]
        return any(g and secrets.compare_digest(g, c["token"]) for g in given)

    def same_origin(self):
        origin = self.headers.get("Origin")
        return not origin or origin == "http://" + (self.headers.get("Host") or "")

    def body(self, limit):
        length = int(self.headers.get("Content-Length") or 0)
        if length > limit:
            return None
        return self.rfile.read(length)

    # ---------- pages ----------
    def page(self, path, extra_head=""):
        with open(path, encoding="utf-8") as f:
            html = f.read()
        tags = HEAD_TAGS + extra_head
        m = re.search(r"<head[^>]*>", html, re.I)
        html = html[:m.end()] + tags + html[m.end():] if m else tags + html
        extra = {}
        k = self.query_key()
        if k and not self.is_computer() and secrets.compare_digest(k, config()["token"]):
            extra["Set-Cookie"] = "dh_k=%s; Max-Age=31536000; Path=/; HttpOnly; SameSite=Lax" % k
        self.send(200, html.encode("utf-8"), "text/html; charset=utf-8", extra)

    def file(self, path):
        ext = os.path.splitext(path)[1].lower()
        try:
            with open(path, "rb") as f:
                body = f.read()
        except OSError:
            return self.send(404, b"Not found", "text/plain")
        if path.endswith("sw.js"):
            # The offline cache must never keep the shared data; always ask the computer for that.
            body = body.replace(b"const url = new URL(e.request.url);",
                                b'const url = new URL(e.request.url);\n  if (url.pathname.startsWith("/api/") || url.pathname === "/feedback.html") return;')
        if path.endswith("manifest.webmanifest"):
            # No fixed start page: the home-screen icon opens the page it was added from, pairing key included.
            m = read_json(path, {})
            m.pop("start_url", None)
            for i in m.get("icons", []):
                i["src"] = "/" + i["src"].lstrip("./")
            body = json.dumps(m).encode()
        self.send(200, body, TYPES.get(ext, "application/octet-stream"))

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/qr.js":
            return self.file(os.path.join(HOST_DIR, "qrcode.js"))
        if OPEN_PATHS.match(path):
            return self.file(os.path.join(APP, path.lstrip("/")))
        if not self.allowed():
            if path.startswith("/api/"):
                return self.send_json({"ok": False, "reason": "not_paired"}, 403)
            msg = ("Phones are switched off on the computer. On the computer, open all systems you, go to More, then "
                   "Times &amp; reminders, and turn on &ldquo;Let our phones in&rdquo;. Then scan the code again."
                   if not config().get("phones") else
                   "This phone isn&rsquo;t paired yet. On the computer, open all systems you, go to More, then "
                   "Times &amp; reminders, and scan the code under Phones.")
            return self.send(403, (NOT_PAIRED % msg).encode(), "text/html; charset=utf-8")
        if path in ("/", "/index.html"):
            return self.page(os.path.join(APP, "index.html"))
        if path in ("/pantry", "/pantry.html"):
            return self.page(os.path.join(APP, "pantry.html"), HELPER_STATE + PANTRY_SYNC)
        if path in ("/checker", "/checker.html"):
            return self.page(os.path.join(APP, "checker.html"), HELPER_STATE)
        if path == "/sources.html":
            return self.page(os.path.join(APP, "sources.html"))
        if path == "/feedback.html":
            return self.page(os.path.join(HOST_DIR, "feedback.html"))
        if path == "/sw.js":
            return self.file(os.path.join(APP, "sw.js"))
        if path == "/api/state":
            with lock:
                state = read_json(STATE, None)
                rev = read_json(REV, {"rev": 0}).get("rev", 0)
            return self.send_json({"server": True, "laptop": self.is_computer(), "state": state, "rev": rev})
        if path.startswith("/api/kv/") and path[8:] in KV_KEYS:
            with lock:
                kv = read_json(os.path.join(DATA, "kv-" + path[8:] + ".json"), {"value": None})
            return self.send_json(kv)
        if path == "/api/info":
            return self.send_json({"version": VERSION, "computer": {"Darwin": "Mac"}.get(SYSTEM, SYSTEM),
                                   "onComputer": self.is_computer(), "email": feedback_email()})
        if path == "/api/phones" and self.is_computer():
            c = config()
            return self.send_json({"enabled": bool(c.get("phones")), "port": PORT, "key": c["token"],
                                   "ips": lan_addresses(), "local": local_name()})
        self.send(404, b"Not found", "text/plain")

    def do_PUT(self):
        path = urlsplit(self.path).path
        if not self.same_origin() or not self.allowed():
            return self.send(403, b"Forbidden", "text/plain")
        raw = self.body(5_000_000)
        if raw is None:
            return self.send(413, b"Too large", "text/plain")
        try:
            data = json.loads(raw)
        except ValueError:
            return self.send(400, b"Bad data", "text/plain")
        if path == "/api/state":
            try:
                state, reminders = data["state"], data.get("reminders", [])
            except (KeyError, TypeError, AttributeError):
                return self.send(400, b"Bad data", "text/plain")
            with lock:
                rev = read_json(REV, {"rev": 0}).get("rev", 0)
                # A window or phone that loaded an older copy must not write over newer changes: send it the newer copy instead.
                if data.get("rev") is not None and data.get("rev") != rev:
                    return self.send_json({"conflict": True, "state": read_json(STATE, None), "rev": rev}, 409)
                daily_backup()
                write_json(STATE, state)
                write_json(REMINDERS, reminders)
                rev += 1
                write_json(REV, {"rev": rev})
            return self.send_json({"ok": True, "rev": rev})
        if path.startswith("/api/kv/") and path[8:] in KV_KEYS:
            if not isinstance(data, dict) or not isinstance(data.get("value"), str):
                return self.send(400, b"Bad data", "text/plain")
            with lock:
                daily_backup()
                write_json(os.path.join(DATA, "kv-" + path[8:] + ".json"), {"value": data["value"], "at": time.time()})
            return self.send_json({"ok": True})
        self.send(404, b"Not found", "text/plain")

    def do_POST(self):
        path = urlsplit(self.path).path
        if not self.same_origin() or not self.allowed():
            return self.send(403, b"Forbidden", "text/plain")
        if path == "/api/label":
            return self.send_json({"ok": False, "reason": "unavailable", "help": "Label photos aren't part of this beta."})
        if path == "/api/phones" and self.is_computer():
            try:
                data = json.loads(self.body(10_000) or b"{}")
            except ValueError:
                data = {}
            with lock:
                c = read_json(CONFIG, {})
                if "enabled" in data:
                    c["phones"] = bool(data["enabled"])
                if data.get("newKey") or not c.get("token"):
                    c["token"] = secrets.token_urlsafe(16)
                write_json(CONFIG, c)
            return self.send_json({"ok": True})
        self.send(404, b"Not found", "text/plain")


def feedback_email():
    """The address feedback goes to, from feedback-email.txt next to the start files (blank if not set)."""
    try:
        with open(os.path.join(KIT, "feedback-email.txt"), encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", line):
                    return line
    except OSError:
        pass
    return ""


def notify(title, body):
    """A desktop pop-up, using what each system already has."""
    if SYSTEM == "Darwin":
        q = lambda s: '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
        cmd = ["osascript", "-e", "display notification %s with title %s sound name \"Glass\"" % (q(body), q(title))]
    elif SYSTEM == "Windows":
        x = lambda s: s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "''")
        ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
              "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null;"
              "$d = New-Object Windows.Data.Xml.Dom.XmlDocument;"
              "$d.LoadXml('<toast scenario=\"reminder\"><visual><binding template=\"ToastGeneric\"><text>%s</text><text>%s</text></binding></visual>"
              "<actions><action content=\"OK\" arguments=\"ok\" activationType=\"system\"/></actions></toast>');"
              "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
              "'{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe')"
              ".Show([Windows.UI.Notifications.ToastNotification]::new($d))") % (x(title), x(body))
        cmd = ["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps]
    elif shutil.which("notify-send"):
        cmd = ["notify-send", "-a", "all systems you", "-u", "critical", title, body]
    else:
        cmd = ["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
               "--object-path", "/org/freedesktop/Notifications",
               "--method", "org.freedesktop.Notifications.Notify",
               "all systems you", "0", "", title, body, "[]", '{"urgency": <byte 2>}', "0"]
    try:
        kw = {"creationflags": 0x08000000} if SYSTEM == "Windows" else {}  # no flashing console window
        subprocess.run(cmd, timeout=20, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
    except (OSError, subprocess.SubprocessError):
        pass
    print("  Reminder %s: %s" % (time.strftime("%H:%M"), title))


def reminder_loop():
    while True:
        now = datetime.datetime.now()
        with lock:
            reminders = read_json(REMINDERS, [])
            fired = read_json(FIRED, {})
        changed = False
        for r in reminders:
            try:
                at = datetime.datetime.strptime(r["at"], "%Y-%m-%dT%H:%M")
            except (KeyError, ValueError, TypeError):
                continue
            # A 30 minute window, so a reminder still shows if the computer was asleep at that minute.
            if at <= now < at + datetime.timedelta(minutes=30) and r.get("key") not in fired:
                notify(r.get("title", "all systems you"), r.get("body", ""))
                fired[r.get("key")] = r["at"]
                changed = True
        cutoff = (now - datetime.timedelta(days=2)).strftime("%Y-%m-%dT%H:%M")
        if changed or any(v < cutoff for v in fired.values()):
            fired = {k: v for k, v in fired.items() if v >= cutoff}
            with lock:
                write_json(FIRED, fired)
        time.sleep(20)


def already_running():
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/api/info" % PORT, timeout=2) as r:
            return "version" in json.loads(r.read())
    except Exception:
        return False


def main():
    url = "http://localhost:%d/" % PORT
    if not os.path.exists(os.path.join(APP, "index.html")):
        print("\nThe app folder is missing. Unzip the whole kit, then start it again.\n")
        return 1
    if already_running():
        print("\nall systems you is already running. Opening it in your browser.\n")
        webbrowser.open(url)
        return 0
    os.makedirs(DATA, exist_ok=True)
    config()
    try:
        # Listens on the Wi-Fi too, but answers phones only when they're switched on and paired.
        server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError:
        print("\nSomething else on this computer is using port %d." % PORT)
        print("Restart the computer and try again. If it keeps happening, tell the person who sent you this kit.\n")
        return 1
    threading.Thread(target=reminder_loop, daemon=True).start()
    print("")
    print("  all systems you beta %s is running." % VERSION)
    print("  Leave this window open while you use it. Close it to stop.")
    print("")
    print("  On this computer:  %s" % url)
    ips = lan_addresses()
    if ips:
        print("  Phones connect by scanning a code in the app: More > Times & reminders > Phones.")
    else:
        print("  This computer isn't on Wi-Fi right now, so phones can't connect yet.")
    print("  Your data is saved in:  %s" % DATA)
    print("")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
