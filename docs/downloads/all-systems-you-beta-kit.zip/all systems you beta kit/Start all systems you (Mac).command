#!/bin/sh
# Double-click to start all systems you. Leave the window open while you use it.
cd "$(dirname "$0")" || exit 1
clear
PY=""
for p in python3 /usr/local/bin/python3 /opt/homebrew/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3; do
  if "$p" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1; then PY="$p"; break; fi
done
if [ -z "$PY" ]; then
  echo ""
  echo "  all systems you needs Python, which is free."
  echo ""
  echo "  If a box just popped up asking to install \"command line developer tools\","
  echo "  click Install and wait for it to finish (it can take 10 minutes)."
  echo "  Otherwise, install Python from the page that is opening now."
  echo ""
  echo "  Then double-click \"Start all systems you (Mac)\" again."
  echo ""
  open "https://www.python.org/downloads/macos/"
  printf "  Press Return to close this window. "; read -r _
  exit 1
fi
"$PY" host/daily_helper_host.py
echo ""
printf "  all systems you has stopped. Press Return to close this window. "; read -r _
